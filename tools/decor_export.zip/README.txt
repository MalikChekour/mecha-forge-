DECOR MECHA-FORGE — 11 IMAGES MANQUANTES A GENERER
====================================================

Pour chaque fichier 01 a 11 : joindre reference_style.png comme image de
reference de style avant de generer, puis utiliser le texte du fichier
comme prompt. Sortie attendue : PNG, fond transparent.

Fichiers :
  01_porte_securite_orbitale.txt
  02_emetteur_laser_rotatif.txt
  03_pilier_energie.txt
  04_segment_mur_modulaire.txt
  05_plaque_de_glace.txt
  06_pic_de_glace.txt
  07_trou_glace_effondree.txt
  08_bassin_liquide_toxique.txt
  09_turbine_geante.txt
  10_grille_ventilation.txt
  11_sol_collant.txt

reference_style.png = copie de game/assets/decor/g27.png (le style a
reproduire : rendu peint numerique, vue 3/4 en plongee, metal industriel,
silhouette nette, fond transparent).
